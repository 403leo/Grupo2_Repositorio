<?php
session_start();
$conn = new mysqli("localhost", "root", "", "biblioteca");

// Cambiar el estado de un libro automáticamente
function actualizarEstadoLibro($libro_id, $nuevo_estado) {
    global $conn;
    $stmt = $conn->prepare("UPDATE libros SET estado = ? WHERE id = ?");
    $stmt->bind_param("si", $nuevo_estado, $libro_id);
    $stmt->execute();
}

// Generar multas automáticamente
function generarMulta($usuario_id, $libro_id, $dias_retraso) {
    global $conn;
    $multa = $dias_retraso * 2; // $2 por día de retraso
    $stmt = $conn->prepare("INSERT INTO multas (usuario_id, libro_id, monto, fecha_creacion) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iid", $usuario_id, $libro_id, $multa);
    $stmt->execute();
}

// Procesar formularios
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Agregar libro
    if (isset($_POST['agregar_libro'])) {
        $titulo = $_POST['titulo'];
        $autor = $_POST['autor'];
        $categoria = $_POST['categoria'];
        $stmt = $conn->prepare("INSERT INTO libros (titulo, autor, categoria, estado) VALUES (?, ?, ?, 'disponible')");
        $stmt->bind_param("sss", $titulo, $autor, $categoria);
        $stmt->execute();
        header("Location: admin.html");
        exit;
    }

    // Agregar usuario
    if (isset($_POST['agregar_usuario'])) {
        $nombre = $_POST['nombre'];
        $correo = $_POST['correo'];
        $password = password_hash("123456", PASSWORD_BCRYPT); // Contraseña predeterminada
        $stmt = $conn->prepare("INSERT INTO usuarios (nombre, correo, contrasena) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nombre, $correo, $password);
        $stmt->execute();
        header("Location: admin.html");
        exit;
    }

    // Enviar notificaciones de devolución
    if (isset($_POST['notificar_devolucion'])) {
        $stmt = $conn->prepare("INSERT INTO notificaciones (usuario_id, mensaje, fecha_envio) VALUES (?, ?, NOW())");
        $mensaje = "Recuerda devolver tu libro antes de la fecha límite.";
        $usuario_id = $_POST['usuario_id'];
        $stmt->bind_param("is", $usuario_id, $mensaje);
        $stmt->execute();
        echo "Notificación enviada.";
    }
}
?>
