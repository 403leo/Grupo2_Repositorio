<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
      <?php include 'styles.css' ?>
      
    </style>
</head>

<body>  
  <div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
        </li>
        <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045"href="services.php">Servicios</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
      </ul>
    </div>
  </div>  
    
 

<!-- Page content -->
<div class="main_div">
  <div id="carouselExampleControls" style="width:30%;left: 30%; top: 60%;"class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100" src="./img/howtoberich.jpg" height="30%" width="10%" alt="First slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="./img/black.png" height="50%" width="200" alt="Second slide">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="./img/Library Logo.png" height="50%" width="200" alt="Third slide">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" style="color:black;" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon"  aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" style="color:black;" role="button" data-slide="next">
      <span class="carousel-control-next-icon"  aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

  <div class="container mt-5">
    <h3>Categorías</h3>
    <div class="row">
      <div class="col-md-4">
      <a href="books.php?categoria=ficcion" class="text-decoration-none">
        <div class="card">
          <img src="./img/ficcion.jpg" class="card-img-top" alt="Fiction">
          <div class="card-body">
            <h5 class="card-title">Ficción</h5>
            <p class="card-text">Explora un mundo de imaginación y aventuras en nuestra categoría de Ficción.</p>
          </div>
        </div>
        </a>
      </div>
      <div class="col-md-4">
      <a href="books.php?categoria=romance" class="text-decoration-none">
        <div class="card">
          <img src="./img/romance.jpg" class="card-img-top" alt="Non-Fiction">
          <div class="card-body">
            <h5 class="card-title">Romance</h5>
            <p class="card-text">Sumérgete en las emociones del amor y la pasión en nuestra categoría de Romance.</p>
          </div>
        </div>
        </a>
      </div>
      <div class="col-md-4">
      <a href="books.php?categoria=historia" class="text-decoration-none">
        <div class="card">
          <img src="./img/historia.jpg" class="card-img-top" alt="Ciencia Ficción">
          <div class="card-body">
            <h5 class="card-title">Historia</h5>
            <p class="card-text">Viajando a través del tiempo y el espacio con la mejor Ciencia Ficción.Descubre los eventos y personajes que dieron forma al mundo en nuestra categoría de Historia.</p>
          </div>
        </div>
      </div>
      </a>
    </div>
  </div>

  <!-- Promotion Section -->
  <div class="container mt-5">
    <h3>¡Promoción Especial en Alquiler de Libros!</h3>
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Alquila 3 libros y recibe un 20% de descuento en el siguiente alquiler</h4>
      <p>Disfruta de nuestra oferta y ahorra en tu próxima visita. Esta promoción es válida solo por tiempo limitado.</p>
    </div>
  </div>
</div>


<div class="footer">
  <h3>Copyright 2024. </h3> </br>
    <div>
    <p class="time"><?php echo "Fecha:" . date('d-m-Y H:i:s'); ?></p>
    </div>
</div>

</body>
</html>


