<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Usuarios</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
      <?php include 'styles.css' ?>
      
    </style>
</head>

<body>  
  <div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
        </li>
        <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045"href="services.php">Servicios</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
      </ul>
    </div>
  </div>  
    


<div class="modulo-libros">
    <h1>Inventario de Libros</h1>

    <!-- Filtros y búsqueda -->
    <form id="filtros-form">
        <select id="categoria" name="categoria">
            <option value="">Todas las Categorías</option>
            <option value="Ficción">Ficción</option>
            <option value="No ficción">Romance</option>
            <option value="Ciencia">Terror y Suspenso</option>
            <option value="Historia">Espirituales</option>
            <option value="Historia">Historia</option>
            <option value="Historia">Autoayuda y Espirituales </option>
            <option value="Historia">Arte</option>
            <option value="Historia">Biografias</option>
        </select>
        
        <input type="text" id="busqueda" name="busqueda" placeholder="Buscar por título o autor">
        <button type="button" onclick="cargarLibros()">Buscar</button>
    </form>

    <!-- Contenedor de libros -->
    <div id="inventario-libros" class="row">
    <!-- Libro de ejemplo 1 -->
    <div class="col-md-3 mb-4">
        <div class="card">
            <img src="./img/libro.png" class="card-img-top" alt="Portada del libro 1">
            <div class="card-body">
                <h5 class="card-title">El Gran Gatsby</h5>
                <p class="card-text">Autor: F. Scott Fitzgerald</p>
                <p class="card-text"><small class="text-muted">Género: Ficción</small></p>
            </div>
        </div>
    </div>
 
    <!-- Libro de ejemplo 2 -->
    <div class="col-md-3 mb-4">
        <div class="card">
            <img src="./img/libro.png" class="card-img-top" alt="Portada del libro 2">
            <div class="card-body">
                <h5 class="card-title">Cien Años de Soledad</h5>
                <p class="card-text">Autor: Gabriel García Márquez</p>
                <p class="card-text"><small class="text-muted">Género: Ficción</small></p>
            </div>
        </div>
    </div>
 
    <!-- Libro de ejemplo 3 -->
    <div class="col-md-3 mb-4">
        <div class="card">
            <img src="./img/libro.png" class="card-img-top" alt="Portada del libro 3">
            <div class="card-body">
                <h5 class="card-title">El Alquimista</h5>
                <p class="card-text">Autor: Paulo Coelho</p>
                <p class="card-text"><small class="text-muted">Género: Espiritualidad</small></p>
            </div>
        </div>
    </div>
 
    <!-- Libro de ejemplo 4 -->
    <div class="col-md-3 mb-4">
        <div class="card">
            <img src="./img/libro.png" class="card-img-top" alt="Portada del libro 4">
            <div class="card-body">
                <h5 class="card-title">1984</h5>
                <p class="card-text">Autor: George Orwell</p>
                <p class="card-text"><small class="text-muted">Género: Ciencia Ficción</small></p>
            </div>
        </div>
    </div>
</div>



    <div class="footer">
  <h3>Copyright 2024. </h3> </br>
    <div>
    <p class="time"><?php echo "Fecha:" . date('d-m-Y H:i:s'); ?></p>
    </div>
</div>

</body>
</html>
