<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
      <?php include 'styles.css' ?>
    </style>
</head>

<body>  
  <div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
        </li>
        <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045"href="services.php">Servicios</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
      </ul>
    </div>
  </div>  
    

<div class="container-user">
    <h2>Inicio de Sesión</h2>
    <form action="login.php" method="POST">
        <input type="email" name="correo" placeholder="Correo electrónico" required>
        <input type="password" name="contrasena" placeholder="Contraseña" required>
        <button type="submit">Iniciar Sesión</button>
    </form>
    <p>¿No tienes una cuenta? <a href="Register.php">Regístrate aquí</a></p>


    <div class="footer">
  <h3>Copyright 2024. </h3> </br>
    <div>
    <p class="time"><?php echo "Fecha:" . date('d-m-Y H:i:s'); ?></p>
    </div>
</div>

</body>
</html>
