<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
      <?php include 'styles.css' ?>
      
    </style>
</head>

<body>

<div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
        </li>
        <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045"href="services.php">Servicios</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
      </ul>
    </div>
  </div>  
    
 
    <!-- Contenedor principal para la información del usuario y libros reservados -->
    <div class="main-content container">
        <!-- Información del usuario -->
        <div class="profile-container">
            <img src="./img/usuario.png" alt="Imagen de perfil" class="profile-image">
            <div class="profile-header">
                <h2>Perfil de Usuario</h2>
            </div>
            <form action="actualizar_usuario.php" method="post">
                <div class="form-group">
                    <label for="numeroUsuario">Número de Usuario</label>
                    <input type="text" class="form-control" id="numeroUsuario" name="numeroUsuario" value="12345" readonly>
                </div>
                <div class="form-group">
                    <label for="nombre">Nombre</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" value="Juan" required>
                </div>
                <div class="form-group">
                    <label for="apellidos">Apellidos</label>
                    <input type="text" class="form-control" id="apellidos" name="apellidos" value="Pérez Villalta" required>
                </div>
                <div class="form-group">
                    <label for="correo">Correo Electrónico</label>
                    <input type="email" class="form-control" id="correo" name="correo" value="juan.perez@example.com" required>
                </div>
                <div class="form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="tel" class="form-control" id="telefono" name="telefono" value="555-1234" required>
                </div>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="juan_perez301" required>
                </div>
                <div class="form-group">
                    <label for="contrasena">Contraseña</label>
                    <input type="password" class="form-control" id="contrasena" name="contrasena" value="1212121221" required>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Actualizar</button>
            </form>
        </div>

        <!-- Libros reservados -->
        <div class="reservas-container">
            <h2>Mis Libros Reservados</h2>
            <table class="table table-bordered table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>#</th>
                        <th>Título</th>
                        <th>Autor</th>
                        <th>Fecha de Reserva</th>
                        <th>Fecha de Devolución</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>El Principito</td>
                        <td>Antoine de Saint-Exupéry</td>
                        <td>01/11/2024</td>
                        <td>15/11/2024</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Cien Años de Soledad</td>
                        <td>Gabriel García Márquez</td>
                        <td>05/11/2024</td>
                        <td>20/11/2024</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>1984</td>
                        <td>George Orwell</td>
                        <td>08/11/2024</td>
                        <td>22/11/2024</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="text-center mt-4">
            <a href="home.php" class="btn btn-danger">Cerrar Sesión</a>
        </div>

        <div class="text-center mt-4">
        </div>



    </div>


    <div class="footer">
  <h3>Copyright 2024. </h3> </br>
    <div>
    <p class="time"><?php echo "Fecha:" . date('d-m-Y H:i:s'); ?></p>
    </div>
</div>

</body>
</html>
