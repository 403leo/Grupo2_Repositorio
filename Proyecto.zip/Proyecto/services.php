<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servicios</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
      <?php include 'styles.css' ?>
      
    </style>
</head>

<body>  
  <div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
        </li>
        <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045"href="services.php">Servicios</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
      </ul>
    </div>
  </div>  

<div class="modulo-servicios">
    <h1>Servicios de Biblioteca</h1>

    <div class="servicios-container">
        <!-- Opción de alquiler -->
        <div class="servicio">
            <h2>Alquiler de Libros</h2>
            <p>Alquila libros por un período de tiempo definido. Busca el libro y realiza el alquiler directamente desde aquí.</p>
            <button onclick="window.location.href='rent.php'">Alquilar Libro</button>
        </div>

        <!-- Opción de venta -->
        <div class="servicio">
            <h2>Venta de Libros</h2>
            <p>Compra libros de nuestra colección. Encuentra el libro que buscas y realiza la compra.</p>
            <button onclick="window.location.href='buy.php'">Comprar Libro</button>
        </div>

        <!-- Opción de devolución -->
        <div class="servicio">
            <h2>Devolución de Libros</h2>
            <p>Devuelve los libros alquilados de manera rápida y sencilla. Mantén tu cuenta al día.</p>
            <button onclick="window.location.href='return.php'">Devolver Libro</button>
        </div>
    </div>

    
    <div class="footer">
  <h3>Copyright 2024. </h3> </br>
    <div>
    <p class="time"><?php echo "Fecha:" . date('d-m-Y H:i:s'); ?></p>
    </div>
</div>

</body>
</html>


