<?php
session_start();

// Conexión a la base de datos
$id_usuario = $_SESSION['id_usuario'];

// Conectar a la base de datos
$conn = new mysqli("localhost", "root", "", "PROYECTO3");

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta para obtener los datos del usuario, incluido id_rol
$sql = "SELECT id_usuario, nombre, apellido, correo, telefono, password, id_rol FROM USUARIO WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

// Verificar si se encontraron datos del usuario
if ($result->num_rows > 0) {
    $usuario = $result->fetch_assoc(); // Obtener los datos del usuario

    // Asignar el id_rol a la sesión
    $_SESSION['id_rol'] = $usuario['id_rol'];
} else {
    // Si no se encuentran datos, redirigir al logout
    header("Location: logout.php");
    exit();
}
// Controlador y modelo
require_once 'Book.php';
require_once 'BookController.php';
$database = new PDO('mysql:host=localhost;dbname=proyecto3', 'root', '');
$bookModel = new Book($database);
$controller = new BookController($bookModel);

// Obtener libros para mostrar
$libros = $controller->showBooks();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestor de Libros</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        <?php include 'styles.css' ?>
    </style>
</head>

<body>
    <div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item">
            <a class="nav-link" style="color:#2e4045" href="profile.php">Perfil</a>
          </li>
        <?php endif; ?>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false): ?>
          <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045" href="services.php">Servicios</a>
          </li>
        <?php endif; ?>
        <li>
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
      </ul>
    </div>
    <div style="left: 35%;" class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item">
          <!-- Enlace que apunta a logout.php para cerrar sesión -->
          <a class="nav-link" style="color:#2e4045" href="logout.php">Cerrar Sesión</a>
          </li>
        <?php endif; ?>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false): ?>
          <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045" href="login.php">Iniciar Sesión</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div> 

    <div class="container mt-5">
        <h1>Libros disponibles</h1>

        <!-- Filtros y búsqueda -->
        
            
            <input type="text" id="busqueda" onKeyUp="cargarLibros()" placeholder="Buscar por título o autor">
        

        <!-- Cards dinámicos para mostrar libros -->
        <div class="row mt-4">
            <?php foreach ($libros as $libro): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?= $libro['nombre'] ?></h5>
                            <p class="card-text"><strong>Autor:</strong> <?= $libro['autor'] ?></p>
                            <p class="card-text"><strong>Stock:</strong> <?= $libro['stock'] ?></p>
                            <p class="card-text"><strong>Año:</strong> <?= $libro['fecha_lanzamiento'] ?></p>

                            
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    

    <div class="footer">
        <h3>Copyright 2024. </h3> </br>
        <div>
            <p class="time"><?php echo "Fecha:" . date('d-m-Y H:i:s'); ?></p>
        </div>
    </div>

    <script>
    function cargarLibros() {     
      // Obtener el valor ingresado en el campo de búsqueda
      const terminoBusqueda = document.getElementById('busqueda').value.toLowerCase();     
      const libros = document.querySelectorAll('.card');     
      // Iterar por cada libro y mostrar u ocultar según el criterio de búsqueda    
      libros.forEach(libro => {         
      const titulo = libro.querySelector('.card-title').innerText.toLowerCase();         
      const autor = libro.querySelector('.card-text').innerText.toLowerCase();                 
      if (titulo.includes(terminoBusqueda) || autor.includes(terminoBusqueda)) {       
        // Mostrar el libro 

        libro.style.display = 'block'; 
        } else { 
          // Ocultar el libro
          libro.style.display = 'none'; 
          
          
          } }); } 
          </script>        



    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>