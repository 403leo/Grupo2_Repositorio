<?php
session_start();

// Conexión a la base de datos
$id_usuario = $_SESSION['id_usuario'];

// Conectar a la base de datos
$conn = new mysqli("localhost", "root", "", "PROYECTO3");

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta para obtener los datos del usuario, incluido id_rol
$sql = "SELECT id_usuario, nombre, apellido, correo, telefono, password, id_rol FROM USUARIO WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

// Verificar si se encontraron datos del usuario
if ($result->num_rows > 0) {
    $usuario = $result->fetch_assoc(); // Obtener los datos del usuario

    // Asignar el id_rol a la sesión
    $_SESSION['id_rol'] = $usuario['id_rol'];
} else {
    // Si no se encuentran datos, redirigir al logout
    header("Location: logout.php");
    exit();
}




?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        <?php include 'styles.css'; ?>
    </style>
</head>

<body>  
  <div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item">
            <a class="nav-link" style="color:#2e4045" href="profile.php">Perfil</a>
          </li>
        <?php endif; ?>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045" href="services.php">Servicios</a>
          </li>
        <?php endif; ?>
        <li>
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
        <?php if (isset($_SESSION['id_rol']) && $_SESSION['id_rol'] == 1): ?>
            <li class="nav-item">
                <a class="nav-link" style="color:#2e4045" href="admin.php">Panel de Administrador</a>
            </li>
        <?php endif; ?>


      </ul>
    </div>
    <div style="left: 35%;" class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item">
          <!-- Enlace que apunta a logout.php para cerrar sesión -->
          <a class="nav-link" style="color:#2e4045" href="logout.php">Cerrar Sesión</a>
          </li>
        <?php endif; ?>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false): ?>
          <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045" href="login.php">Iniciar Sesión</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div> 
    
 

<!-- Page content -->
<div class="main_div">
        <!-- Carrusel -->
        <div id="carouselExampleControls" style="width: 30%; left: 30%; top: 60%;" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="./img/Imagen 1.jpg" height="30%" width="10%" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="./img/Imagen 2.jpg" height="50%" width="200" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="./img/Imagen 3.jpg" height="50%" width="200" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>

  <div class="container mt-5">
    <h3>Categorías</h3>
    <div class="row">
      <div class="col-md-4">
      <a href="books.php?categoria=ficcion" class="text-decoration-none">
        <div class="card">
          <img src="./img/ficcion.jpg" class="card-img-top" alt="Fiction">
          <div class="card-body">
            <h5 class="card-title">Ficción</h5>
            <p class="card-text">Explora un mundo de imaginación y aventuras en nuestra categoría de Ficción.</p>
          </div>
        </div>
        </a>
      </div>
      <div class="col-md-4">
      <a href="books.php?categoria=romance" class="text-decoration-none">
        <div class="card">
          <img src="./img/romance.jpg" class="card-img-top" alt="Non-Fiction">
          <div class="card-body">
            <h5 class="card-title">Romance</h5>
            <p class="card-text">Sumérgete en las emociones del amor y la pasión en nuestra categoría de Romance.</p>
          </div>
        </div>
        </a>
      </div>
      <div class="col-md-4">
      <a href="books.php?categoria=historia" class="text-decoration-none">
        <div class="card">
          <img src="./img/historia.jpg" class="card-img-top" alt="Ciencia Ficción">
          <div class="card-body">
            <h5 class="card-title">Historia</h5>
            <p class="card-text">Viajando a través del tiempo y el espacio con la mejor Ciencia Ficción.Descubre los eventos y personajes que dieron forma al mundo en nuestra categoría de Historia.</p>
          </div>
        </div>
      </div>
      </a>
    </div>
  </div>

  <!-- Promotion Section -->
  <div class="container mt-5">
    <h3>¡Promoción Especial en Alquiler de Libros!</h3>
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Alquila 3 libros y recibe un 20% de descuento en el siguiente alquiler</h4>
      <p>Disfruta de nuestra oferta y ahorra en tu próxima visita. Esta promoción es válida solo por tiempo limitado.</p>
    </div>
  </div>
</div>


<div class="footer">
  <h3>Copyright 2024. </h3> </br>
    <div>
    <p class="time"><?php echo "Fecha:" . date('d-m-Y H:i:s'); ?></p>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</body>
</html>


