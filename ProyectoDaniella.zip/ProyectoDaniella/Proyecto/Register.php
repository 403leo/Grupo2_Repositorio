<?php
////DB CONECTION
$conn = new mysqli("localhost", "root", "", "PROYECTO3");

if ($conn->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}




// Verificar si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $apellido = $_POST['apellido'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $password = $_POST['password'] ?? '';

    //$password_hashed = password_hash($password, PASSWORD_DEFAULT);


    // Validar los campos requeridos
    if ($nombre && $apellido && $correo && $telefono && $password > 0) {
        // Verificar si el correo ya existe en la base de datos
        $sql_check_email = "SELECT COUNT(*) FROM USUARIO WHERE correo = ?";
        $stmt_check_email = $conn->prepare($sql_check_email);
        $stmt_check_email->bind_param('s', $correo);
        $stmt_check_email->execute();
        $stmt_check_email->bind_result($count_email);
        $stmt_check_email->fetch();
        $stmt_check_email->close();

        if ($count_email > 0) {
            // Si el correo ya existe, mostrar un mensaje de error
            $message = 'El correo electrónico ya está registrado. Por favor, usa otro correo.';
        } else {
            // Verificar si el teléfono ya existe en la base de datos
            $sql_check_phone = "SELECT COUNT(*) FROM USUARIO WHERE telefono = ?";
            $stmt_check_phone = $conn->prepare($sql_check_phone);
            $stmt_check_phone->bind_param('s', $telefono);
            $stmt_check_phone->execute();
            $stmt_check_phone->bind_result($count_phone);
            $stmt_check_phone->fetch();
            $stmt_check_phone->close();

            if ($count_phone > 0) {
                // Si el teléfono ya existe, mostrar un mensaje de error
                
                $message = 'El número de teléfono ya está registrado. Por favor, usa otro número.';
            } else {
                // Si el correo y el teléfono no existen, proceder a insertar el nuevo usuario
                $sql = "INSERT INTO USUARIO (nombre, apellido, correo, telefono, password) 
                        VALUES (?, ?, ?, ?, ?)";

                $stmt = $conn->prepare($sql);
                $stmt->bind_param('sssss', $nombre, $apellido, $correo, $telefono, $password);

                if ($stmt->execute()) {
                    header('Location: login.php');     
                    exit;
                    $message = 'Usuario registrado exitosamente.';
                } else {
                    $message = 'Error al registrar el usuario: ' . $stmt->error;
                }

                $stmt->close();
            }
        }
    } else {
        $message = 'Por favor, complete todos los campos requeridos.';
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Usuarios</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
      <?php include 'styles.css'?>
    </style>
    <script>
      
function togglePasswordVisibility() {
            const passwordField = document.getElementById('password');
            const toggleButton = document.getElementById('togglePassword');
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
            } else {
                passwordField.type = 'password';
            }
        }
    </script>
</head>
<body>
<div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
        </li>
        <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045"href="services.php">Servicios</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
      </ul>
    </div>
  </div>  
</div>
    <!-- Contenido del formulario -->
    <h1>Registro de Usuario</h1>
    <div class="container-user">
    <form method="POST" action="">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required>
        <label for="correo">Correo:</label>
        <input type="email" id="correo" name="correo" required>

        <label for="telefono">Teléfono:</label>
        <input type="text" id="telefono" name="telefono" required>

        <label for="password">Contraseña:</label>
            <input  class="contrasena" style="margin-bottom: 0;"type="password" id="password" name="password" required>
            <p id="togglePassword" onclick="togglePasswordVisibility()" class="mostrar">Mostrar Contraseña</p>
        <button type="submit" href="login.php">Registrar</button>
        
    </form>
    <!-- Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal()">&times;</span>
            <p id="modalMessage"></p> <!-- Aquí se mostrará el mensaje -->
        </div>
    </div>

    <!-- JavaScript para mostrar el modal -->
    <script>

        // Función para mostrar el modal
        function showModal(message) {
            document.getElementById('modalMessage').innerText = message;
            document.getElementById('myModal').style.display = 'block';
        }

        // Función para cerrar el modal
        function closeModal() {
            document.getElementById('myModal').style.display = 'none';
        }

        // Si el PHP establece un mensaje, lo mostramos en el modal
        <?php if ($message != ''): ?>
            showModal("<?php echo $message; ?>");
        <?php endif; ?>

        // Cerrar el modal si el usuario hace clic fuera de él
        window.onclick = function(event) {
            if (event.target == document.getElementById('myModal')) {
                closeModal();
            }
        }
    </script>
</body>
</html>
