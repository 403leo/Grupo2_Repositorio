<?php
session_start();
require_once 'MultaController.php';
// Conexión a la base de datos
$idUsuario = $_SESSION['id_usuario'];

// Conectar a la base de datos
$conn = new mysqli("localhost", "root", "", "PROYECTO3");

if ($conn->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];
$sql = "SELECT id_usuario, nombre, apellido, correo, telefono, password FROM USUARIO WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $usuario = $result->fetch_assoc(); // Obtener los datos del usuario
} else {
    header("Location: logout.php");
    exit();
}

// Crear el controlador y mostrar multas
$controller = new MultaController($conn);
$multas = $controller->mostrarMultas($idUsuario);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        <?php include 'styles.css'; ?>
        /* Contenedor para centrar la tabla */
.contenedor-tabla {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh; /* Ocupa toda la altura de la página */
    margin: 0;
}

/* Estilo para la tabla */
.tabla-multas {
    border-collapse: collapse;
    width: 70%;
    text-align: center;
    background-color: #f9f9f9;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    overflow: hidden; /* Para bordes redondeados */
}

/* Estilo para las celdas y encabezados */
.tabla-multas th, .tabla-multas td {
    padding: 12px;
    border: 1px solid #ddd;
}

.tabla-multas th {
    background-color: #007bff;
    color: #ffffff;
    font-weight: bold;
    text-transform: uppercase;
}

/* Filas alternas */
.tabla-multas tr:nth-child(even) {
    background-color: #f2f2f2;
}

/* Efecto hover */
.tabla-multas tr:hover {
    background-color: #d1ecf1;
    cursor: pointer;
}
    </style>
</head>

<body>
<div class="header">
    <div class="mr-3">
        <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" style="color:#2e4045" href="services.php">Servicios</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
            </li>
        </ul>
    </div>
</div>

<div class="main-content container">
    <!-- Información del usuario visible -->
    <div class="profile-container">
        <img src="./img/usuario.png" alt="Imagen de perfil" class="profile-image">
        <div class="profile-header">
            <h2>Perfil de Usuario</h2>
        </div>
        <ul class="list-group">
            <li class="list-group-item"><strong>ID Usuario:</strong> <?php echo $usuario['id_usuario']; ?></li>
            <li class="list-group-item"><strong>Nombre:</strong> <?php echo $usuario['nombre']; ?></li>
            <li class="list-group-item"><strong>Apellido:</strong> <?php echo $usuario['apellido']; ?></li>
            <li class="list-group-item"><strong>Correo Electrónico:</strong> <?php echo $usuario['correo']; ?></li>
            <li class="list-group-item"><strong>Teléfono:</strong> <?php echo $usuario['telefono']; ?></li>
        </ul>
        <button type="button" class="btn btn-primary btn-block mt-3" data-toggle="modal" data-target="#editModal">
            Editar Información
        </button>
    </div>
</div>

<!-- Modal para editar información -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <h3>Servicio no disponible. Por favor contacte a servicio al cliente. <br>
                Correo: servicio@libreria-fide.com</h3>
        </div>
    </div>
</div>

<div class="text-center mt-4">
    <a href="logout.php" class="btn btn-danger">Cerrar Sesión</a>
</div>

<h1 style="text-align: center;">Mis Multas</h1>
    <?php if (!empty($multas)): ?>
        <div class="contenedor-tabla">
            <table class="tabla-multas">
                <thead>
                    <tr>
                        <th>ID Multa</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($multas as $multa): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($multa['id_multa']); ?></td>
                            <td><?php echo htmlspecialchars($multa['descripcion']); ?></td>
                            <td><?php echo number_format($multa['precio_multa'], 2); ?> €</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p>No tiene multas registradas.</p>
    <?php endif; ?>

<div class="footer">
    <h3>Copyright 2024. </h3>
    <p class="time"><?php echo "Fecha: " . date('d-m-Y H:i:s'); ?></p>
</div>

<!-- Scripts necesarios -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>