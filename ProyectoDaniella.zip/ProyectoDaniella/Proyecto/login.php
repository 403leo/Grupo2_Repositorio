<?php
////DB CONECTION
$conn = new mysqli("localhost", "root", "", "PROYECTO3");

if ($conn->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}


// Inicializar variables de error y mensaje
$error_message = "";

// Verificar si el formulario ha sido enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';

    // Verificar si ambos campos no están vacíos
    if (!empty($correo) && !empty($contrasena)) {
        // Consulta SQL para verificar si el correo y la contraseña coinciden
        $sql = "SELECT * FROM USUARIO WHERE correo = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $correo);
        $stmt->execute();
        $result = $stmt->get_result();

        // Si el correo existe en la base de datos
        if ($result->num_rows > 0) {
            // Obtener los datos del usuario
            $usuario = $result->fetch_assoc();
            
            // Verificar la contraseña usando bcrypt
            if ($contrasena == $usuario['password']) {
                // Si las credenciales son correctas, iniciar sesión (por ejemplo, redirigir al perfil)
                session_start();
                $_SESSION['id_usuario'] = $usuario['id_usuario']; // Asumiendo que 'id' es el identificador único del usuario CAMBIE ESTO PARA QUE ALMACENARA CON EL USUARIO
                $_SESSION['user_name'] = $usuario['nombre']; // Nombre del usuario, puedes usar otros campos si deseas
                $_SESSION['logged_in'] = true;
                header("Location: home.php"); // Redirigir al home después de iniciar sesión
                exit;
            } else {
                $error_message = "Contraseña incorrecta.";
            }
        } else {
            $error_message = "Correo electrónico no registrado.";
        }
    } else {
        $error_message = "Por favor, ingresa tanto el correo como la contraseña.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <style>
      <?php include 'styles.css'; ?>
    </style>
</head>

<body>  
<div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item">
            <a class="nav-link" style="color:#2e4045" href="profile.php">Perfil</a>
          </li>
        <?php endif; ?>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false): ?>
          <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045" href="services.php">Servicios</a>
          </li>
        <?php endif; ?>
        <li>
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
      </ul>
    </div>
    <div style="left: 35%;" class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item">
          <!-- Enlace que apunta a logout.php para cerrar sesión -->
          <a class="nav-link" style="color:#2e4045" href="logout.php">Cerrar Sesión</a>
          </li>
        <?php endif; ?>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false): ?>
          <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045" href="login.php">Iniciar Sesión</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div> 

  <div class="container-user">
    <h2>Inicio de Sesión</h2>
    <form action="login.php" method="POST">
        <input type="email" name="correo" placeholder="Correo electrónico" required>
        <input type="password" name="contrasena" placeholder="Contraseña" required>
        <button type="submit">Iniciar Sesión</button>
    </form>

    <p>¿No tienes una cuenta? <a href="Register.php">Regístrate aquí</a></p>

    <?php
    // Mostrar mensaje de error si existe
    if ($error_message != "") {
        echo "<div class='alert alert-danger'>$error_message</div>";
    }
    ?>

    <div class="footer">
      <h3>Copyright 2024.</h3>
      <div>
        <p class="time"><?php echo "Fecha: " . date('d-m-Y H:i:s'); ?></p>
      </div>
    </div>
  </div>
</body>
</html>
