<?php
// Conexión a la base de datos
$connection = new mysqli("localhost", "root", "", "proyecto3");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Lógica para actualizar notificaciones, sin enviar correos
$query = "
    SELECT p.id_usuario, d.fecha_caducidad 
    FROM DEVOLUCION d 
    JOIN PEDIDO p ON d.id_pedido = p.id_pedido 
    WHERE d.fecha_caducidad < CURDATE() AND d.id_estado != 9
";
$stmt = $connection->prepare($query);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($id_usuario, $fecha_caducidad);

while ($stmt->fetch()) {
    if (!empty($id_usuario)) {
        // Aquí estaba la lógica de sendNotification()
    }
}

$stmt->free_result();
$stmt->close();
?>
