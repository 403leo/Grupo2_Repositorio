<?php
class MultaModel {
    private $db;

    public function __construct($conexion) {
        $this->db = $conexion;
    }

    // Obtener multas activas de un usuario específico
    public function obtenerMultasPorUsuario($idUsuario) {
        $query = "SELECT id_multa, descripcion, precio_multa 
                  FROM multa 
                  WHERE id_usuario = ? AND id_estado = 1";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $idUsuario);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->fetch_all(MYSQLI_ASSOC);
    }
}
?>