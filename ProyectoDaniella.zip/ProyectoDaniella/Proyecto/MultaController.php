<?php
require_once 'MultaModel.php';

class MultaController {
    private $multaModel;

    public function __construct($conexion) {
        $this->multaModel = new MultaModel($conexion);
    }

    public function mostrarMultas($idUsuario) {
        // Obtener las multas desde el modelo
        return $this->multaModel->obtenerMultasPorUsuario($idUsuario);

    }
}
?>
