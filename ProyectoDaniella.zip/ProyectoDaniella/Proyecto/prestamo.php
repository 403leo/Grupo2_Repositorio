<?php
session_start(); // Iniciar sesión

// Verificar si el usuario está autenticado
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php"); // Redirigir si no está autenticado
    exit;
}

// Conexión a la base de datos
require 'db_connection.php';

// Verificar si se proporcionó un ID de libro
if (!isset($_GET['id_libro'])) {
    header("Location: rent.php"); // Redirigir si falta el ID del libro
    exit;
}

$id_libro = (int)$_GET['id_libro']; // Obtener el ID del libro
$id_usuario = $_SESSION['user_id']; // Obtener el ID del usuario autenticado

try {
    // Iniciar transacción
    $conn->beginTransaction();

    // Verificar si el libro tiene stock disponible
    $queryStock = "SELECT stock FROM libro WHERE id_libro = :id_libro AND id_estado = 1";
    $stmtStock = $conn->prepare($queryStock);
    $stmtStock->execute(['id_libro' => $id_libro]);
    $stock = $stmtStock->fetchColumn();

    if ($stock === false || $stock <= 0) {
        throw new Exception("El libro no está disponible para reservar.");
    }

    // Insertar el préstamo en la tabla PEDIDO
    $queryInsert = "INSERT INTO pedido (id_usuario, id_libro, id_estado, FECHA_PEDIDO) 
                    VALUES (:id_usuario, :id_libro, 2, NOW())";
    $stmtInsert = $conn->prepare($queryInsert);
    $stmtInsert->execute([
        'id_usuario' => $id_usuario,
        'id_libro' => $id_libro
    ]);

    // Reducir el stock del libro
    $queryUpdateStock = "UPDATE libro SET stock = stock - 1 WHERE id_libro = :id_libro";
    $stmtUpdateStock = $conn->prepare($queryUpdateStock);
    $stmtUpdateStock->execute(['id_libro' => $id_libro]);

    // Confirmar transacción
    $conn->commit();

    // Redirigir a rent.php con un mensaje de éxito
    header("Location: rent.php?message=Reserva realizada con éxito");
    exit;
} catch (Exception $e) {
    // Revertir transacción en caso de error
    $conn->rollBack();
    // Redirigir con un mensaje de error
    header("Location: rent.php?error=" . urlencode($e->getMessage()));
    exit;
}
