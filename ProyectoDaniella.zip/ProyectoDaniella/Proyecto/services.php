<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$id_usuario = $_SESSION['id_usuario'];

// Conectar a la base de datos
$conn = new mysqli("localhost", "root", "", "PROYECTO3");

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta para obtener los datos del usuario, incluido id_rol
$sql = "SELECT id_usuario, nombre, apellido, correo, telefono, password, id_rol FROM USUARIO WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

// Verificar si se encontraron datos del usuario
if ($result->num_rows > 0) {
    $usuario = $result->fetch_assoc(); // Obtener los datos del usuario

    // Asignar el id_rol a la sesión
    $_SESSION['id_rol'] = $usuario['id_rol'];
} else {
    // Si no se encuentran datos, redirigir al logout
    header("Location: logout.php");
    exit();
}




?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servicios</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
      <?php include 'styles.css' ?>
      
    </style>
</head>

<body>  
<div class ="header">
    <div class="mr-3">
      <img class="logo" src="./img/Library Logo.png" height="100">
    </div>
    <div class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
        </li>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item">
            <a class="nav-link" style="color:#2e4045" href="profile.php">Perfil</a>
          </li>
        <?php endif; ?>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045" href="services.php">Servicios</a>
          </li>
        <?php endif; ?>
        <li>
          <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
        </li>
        <?php if (isset($_SESSION['id_rol']) && $_SESSION['id_rol'] == 1): ?>
            <li class="nav-item">
                <a class="nav-link" style="color:#2e4045" href="admin.php">Panel de Administrador</a>
            </li>
        <?php endif; ?>


      </ul>
    </div>
    <div style="left: 35%;" class="navbar d-flex justify-content-between w-100">
      <ul class="nav">
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true): ?>
          <li class="nav-item">
          <!-- Enlace que apunta a logout.php para cerrar sesión -->
          <a class="nav-link" style="color:#2e4045" href="logout.php">Cerrar Sesión</a>
          </li>
        <?php endif; ?>
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == false): ?>
          <li class="nav-item"> 
          <a class="nav-link" style="color:#2e4045" href="login.php">Iniciar Sesión</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div> 
      

<div class="modulo-servicios">
    <h1>Servicios de Biblioteca</h1>

    <div class="servicios-container">
        <!-- Opción de alquiler -->
        <div class="servicio">
            <h2>Alquiler de Libros</h2>
            <p>Alquila libros por un período de tiempo definido. Busca el libro y realiza el alquiler directamente desde aquí.</p>
            <button onclick="window.location.href='rent.php'">Alquilar Libro</button>
        </div>
        
        <!-- Opción de devolución -->
        <div class="servicio">
            <h2>Devolución de Libros</h2>
            <p>Devuelve los libros alquilados de manera rápida y sencilla. Mantén tu cuenta al día.</p>
            <button onclick="window.location.href='return.php'">Devolver Libro</button>
        </div>
    </div>

    
    <div class="footer">
  <h3>Copyright 2024. </h3> </br>
    <div>
    <p class="time"><?php echo "Fecha:" . date('d-m-Y H:i:s'); ?></p>
    </div>
</div>

</body>
</html>


