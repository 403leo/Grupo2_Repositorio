<?php

session_start(); // Asegúrate de llamar a session_start() al principio de cada página que utilice sesiones.
 
if (!isset($_SESSION['logged_in'])) {
  $_SESSION['logged_in'] = false; // Usuario no autenticado por defecto
}


// Include the notifications file 
include 'notificaciones.php';


// Conexión a la base de datos
$connection = new mysqli("localhost", "root", "", "PROYECTO3");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

//Agregar Libro

if (isset($_POST['agregar_libro'])) {
    $titulo = $_POST['titulo'];
    $autor = $_POST['autor'];
    $categoria = $_POST['categoria'];
    $stock = $_POST['stock'];
    
    // Verificar si todos los campos están completos
    if (!empty($titulo) && !empty($autor) && !empty($categoria) && !empty($stock)) {
        // Insertar los datos en la base de datos
        $sql = "INSERT INTO LIBRO (id_categoria, id_estado, nombre, stock, autor, fecha_lanzamiento, editorial) 
                VALUES ('$categoria', 1, '$titulo', '$stock', '$autor', CURDATE(), 'Editorial de prueba')";
        
        if ($connection->query($sql) === TRUE) {
            echo "Libro agregado con éxito!";
            header('Location: admin.php'); // Recargar la página para mostrar la lista actualizada
            exit(); // Asegurar que el script se detenga después de la redirección
        } else {
            echo "Error: " . $connection->error;
        }
    } else {
        echo "Por favor, complete todos los campos.";
    }
}


// Obtener lista de libros
$sql_libros = "
    SELECT 
        L.*, 
        E.nombre AS estado_libro 
    FROM 
        LIBRO L
    JOIN 
        ESTADO E ON L.id_estado = E.id_estado
";
$result_libros = $connection->query($sql_libros);

// Obtener las categorias de los libros 

$sql_categorias = " SELECT id_categoria, nombre FROM CATEGORIA WHERE id_estado = 1";
$result_categorias = $connection->query($sql_categorias);

//CAMBIAR ESTADO DEL LIBRO

if (isset($_POST['cambiar_estado'])) {
    $id_libro = $_POST['id_libro'];

    // Obtener el estado actual del libro
    $sql_estado = "SELECT id_estado FROM LIBRO WHERE id_libro = '$id_libro'";
    $result_estado = $connection->query($sql_estado);
    $row_estado = $result_estado->fetch_assoc();

    // Cambiar el estado (si está activo, lo ponemos inactivo, si está inactivo lo ponemos activo)
    $nuevo_estado = ($row_estado['id_estado'] == 1) ? 0 : 1;

    // Actualizar el estado en la base de datos
    $sql_update = "UPDATE LIBRO SET id_estado = '$nuevo_estado' WHERE id_libro = '$id_libro'";

    if ($connection->query($sql_update) === TRUE) {
        echo "Estado del libro actualizado con éxito!";
    } else {
        echo "Error: " . $connection->error;
    }
}
///eEditar libro
if (isset($_POST['editar_libro'])) {
    $id_libro = $_POST['id_libro'];
    $nombre = $_POST['nombre'];
    $autor = $_POST['autor'];
    $stock = $_POST['stock'];

    $sql = "UPDATE LIBRO SET nombre = '$nombre', autor = '$autor', stock = '$stock' WHERE id_libro = '$id_libro'";

    if ($connection->query($sql) === TRUE) {
        echo "Libro actualizado con éxito!";
        header('Location: admin.php'); 
    } else {
        echo "Error: " . $connection->error;
    }
}


// Agregar usuario
if (isset($_POST['agregar_usuario'])) {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $contraseña = $_POST['password']; // Se guarda la contraseña en la base de datos

    $rol = 3; // Se asigna el rol de "Usuario" por defecto
    
    // Encriptar la contraseña antes de almacenarla
    //$hashed_password = password_hash($contraseña, PASSWORD_DEFAULT);
    
    $sql = "INSERT INTO USUARIO (id_rol, id_estado, nombre, apellido, correo, telefono, password) 
            VALUES ('$rol', 1, '$nombre', '$apellido', '$correo', '$telefono', '$contraseña')";
    
    if ($connection->query($sql) === TRUE) {
        echo "Usuario agregado con éxito!";
    } else {
        echo "Error: " . $connection->error;
    }
}

// Obtener lista de usuarios
$sql_usuarios = "SELECT * FROM USUARIO";
$result_usuarios = $connection->query($sql_usuarios);

// Editar usuario
if (isset($_POST['editar_usuario'])) {
    $id_usuario = $_POST['id_usuario'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
            
// Actualizar la información del usuario en la base de datos
$sql = "UPDATE USUARIO SET nombre = '$nombre', apellido = '$apellido', correo = '$correo', telefono = '$telefono' WHERE id_usuario = '$id_usuario'";
            
    if ($connection->query($sql) === TRUE) {
        echo "Usuario actualizado con éxito!";
        header('Location: admin.php'); 
    } else {
        echo "Error: " . $connection->error;
    }
}


// Obtener reservas activas con JOINs para obtener el nombre del usuario y nombre del libro
// Obtener reservas activas con JOINs para obtener el nombre del usuario y nombre del libro
$sql_reservas = "
    SELECT 
        p.id_pedido, 
        u.nombre AS nombre_usuario, 
        l.nombre AS nombre_libro, 
        e.nombre AS estado_libro, 
        p.fecha_pedido
    FROM 
        PEDIDO p
    JOIN 
        USUARIO u ON p.id_usuario = u.id_usuario
    JOIN 
        LIBRO l ON p.id_libro = l.id_libro
    JOIN
        ESTADO e ON p.id_estado = e.id_estado
    WHERE 
        p.id_estado = 3"; // Estado 'Pendiente' por ejemplo

// Ejecutar la consulta y verificar si se obtuvo un resultado
$result_reservas = $connection->query($sql_reservas);


        
// Obtener pedidos activos
$sql_pedidos = "SELECT * FROM PEDIDO WHERE id_estado = 1"; // Estado 'Activo'
$result_pedidos = $connection->query($sql_pedidos);


// Fetch notifications from the database to display in the admin panel
$notifications_query = "SELECT * FROM NOTIFICACIONES";
$notifications_result = $connection->query($notifications_query);

// notificacione predeterminadas 
if (isset($_POST['send_notification'])) {
    $user_id = $_POST['user_id'];
    $id_notificacion = $_POST['notification_name'];

    // Obtener el mensaje de la notificación seleccionada
    $sql_mensaje = "SELECT mensaje FROM NOTIFICACIONES_PREDEFINIDAS WHERE id_notificacion = '$id_notificacion'";
    $result_mensaje = $connection->query($sql_mensaje);
    $mensaje = '';

    if ($result_mensaje->num_rows > 0) {
        $row_mensaje = $result_mensaje->fetch_assoc();
        $mensaje = $row_mensaje['mensaje'];
    }

    // Insertar la notificación en la tabla de notificaciones
    $sql = "INSERT INTO NOTIFICACIONES (id_usuario, nombre, id_estado, mensaje) 
            VALUES ('$user_id', (SELECT nombre FROM NOTIFICACIONES_PREDEFINIDAS WHERE id_notificacion = '$id_notificacion'), 1, '$mensaje')";

    if ($connection->query($sql) === TRUE) {
        echo "Notificación enviada con éxito!";
        header('Location: admin.php'); // Recargar la página para ver la lista de notificaciones actualizada
        exit();
    } else {
        echo "Error: " . $connection->error;
    }
}
///obtener notificaciones enviadas

// Agregar multa
if (isset($_POST['agregar_multa'])) {
    $id_usuario = $_POST['id_usuario'];
    $descripcion = $_POST['descripcion'];
    $precio_multa = $_POST['precio_multa'];

    $sql = "INSERT INTO MULTA (id_usuario, id_estado, descripcion, precio_multa) 
            VALUES ('$id_usuario', 1, '$descripcion', '$precio_multa')";

    if ($connection->query($sql) === TRUE) {
        echo "Multa agregada con éxito!";
    } else {
        echo "Error: " . $connection->error;
    }
}


?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administrador</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <style>
        .list-item {
            display: flex;
            justify-content: space-between; /* Justifica el contenido */
            align-items: center; /* Alinea verticalmente */
            margin-bottom: 10px; /* Espacio entre los elementos de la lista */
        }

        .list-item button {
            margin-left: 10px; /* Espacio entre el texto y el botón */
        }

        .opciones {
            display: none;
            position: absolute;
            background-color: white;
            border: 1px solid #ddd;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 10px;
            margin-top: 5px;
            width: 150px;
        }

        .opciones a {
            text-decoration: none;
            color: black;
        }

        .opciones a:hover {
            background-color: #f1f1f1;
            padding: 5px;
        }
    </style>
</head>




<body>

<div class="admin-panel">
    <header>
        <h1>Panel de Administrador</h1>
    </header>

    <!-- Gestión de libros -->
    <section>
        <div id="listado-libros">
            <div class = "container">
                <div class ="row">
                    <div class = "col-sm">
                        <h2>Gestion de Libros</h2>
                    </div>
                    <div class = "col-sm">
                    <button class="btn btn-success" data-toggle="modal" data-target="#addBookModal">Agregar Libro</button>

                    </div>
                </div>
            </div>

            <div class="modal fade" id="addBookModal" tabindex="-1" role="dialog" aria-labelledby="addBookModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBookModalLabel">Agregar Nuevo Libro</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form-agregar-libro" action="admin.php" method="POST">
                    <div class="form-group">
                        <label for="titulo_agregar">Título</label>
                        <input type="text" class="form-control" name="titulo" id="titulo_agregar" placeholder="Ingrese el título del libro" required>
                    </div>
                    <div class="form-group">
                        <label for="autor_agregar">Autor</label>
                        <input type="text" class="form-control" name="autor" id="autor_agregar" placeholder="Ingrese el autor del libro" required>
                    </div>
                    <div class="form-group">
                        <label for="categoria_agregar">Categoria</label>
                        <select class="form-control" name="categoria" id="categoria_agregar" required>
                            <option value="">Seleccione una categoría</option>
                            <?php while ($row = $result_categorias->fetch_assoc()) {?>
                                <option value="<?php echo $row['id_categoria']; ?>">
                                
                                    <?php echo $row['nombre']; ?>

                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    

                    <div class="form-group">
                        <label for="stock_agregar">Stock</label>
                        <input type="number" class="form-control" name="stock" id="stock_agregar" placeholder="Ingrese la cantidad de libros en stock" required>
                    </div>
                    <button type="submit" name="agregar_libro" class="btn btn-primary">Agregar Libro</button>
                </form>
            </div>
        </div>
    </div>
</div>

        
      
            <table class="table">
                <thead>
                    <tr>
                        <th>Titulo</th>
                        <th>Autor</th>
                        <th>Stock</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php while ($row = $result_libros->fetch_assoc()) { ?>
                        <tr >
                             <td><?php echo $row['nombre'];?></td>
                             <td><?php echo $row['autor'];?></td>
                             <td><?php echo $row['stock'];?></td>
                             <td><?php echo $row ['estado_libro'];?></td>
                             <td><button class="btn btn-warning"  onclick="mostrarModalEditarLibro(<?php echo $row['id_libro']; ?>, '<?php echo $row['nombre']; ?>', '<?php echo $row['autor']; ?>', '<?php echo $row['stock']; ?>')">Editar</button></td>
                    </tr>
                    <?php } ?>
                    </tbody>
                    </table>
        </div>
        </section>

<div class="modal fade" id="editBookModal" tabindex="-1" role="dialog" aria-labelledby="editBookModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editBookModalLabel">Editar Libro</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form-editar-libro" action="admin.php" method="POST">
                    <input type="hidden" name="id_libro" id="id_libro_editar">
                    <div class="form-group">
                        <label for="nombre_editar">Título</label>
                        <input type="text" class="form-control" name="nombre" id="nombre_editar" required>
                    </div>
                    <div class="form-group">
                        <label for="autor_editar">Autor</label>
                        <input type="text" class="form-control" name="autor" id="autor_editar" required>
                    </div>
                    <div class="form-group">
                        <label for="stock_editar">Stock</label>
                        <input type="number" class="form-control" name="stock" id="stock_editar" required>
                    </div>
                    <button type="submit" name="editar_libro" class="btn btn-primary">Guardar Cambios</button>
                </form>
            </div>
        </div>
    </div>
</div>
  <!-- Gestión de usuarios -->
    <section>
        <div id="listado-usuarios"> 
            <div class = "container">
                <div class ="row">
                    <div class = "col-sm">
                        <h3>Gestion de Usuarios</h3>
                    </div>
                    <div class = "Col-sm">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#addUserModal">Agregar Usuario</button>
                    </div>
                </div>
            </div>
                
        <!-- Modal para agregar usuario -->
        <div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addUserModalLabel">Agregar Nuevo Usuario</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Formulario dentro del modal -->
                        <form id="form-usuarios" action="admin.php" method="POST">
                            <div class="form-group">
                                <input type="text" class="form-control" name="nombre" placeholder="Nombre del usuario" required>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="apellido" placeholder="Apellido del usuario" required>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="correo" placeholder="Correo electrónico" required>
                            </div>
                            <div class="form-group">
                                <input type="tel" class="form-control" name="telefono" placeholder="Teléfono del usuario" required>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password" placeholder="Contraseña" required>
                            </div>
                            <button type="submit" name="agregar_usuario" class="btn btn-primary">Agregar Usuario</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <table class="table">
        <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result_usuarios->fetch_assoc()) { ?>
                    <tr >
                        <td><?php echo $row['id_usuario'];?></td>
                        <td><?php echo $row['nombre'] . " " . $row['apellido']; ?></td>
                        <td><?php echo $row['correo']; ?></td>
                        <td><?php echo $row['telefono']; ?></td>
                        <td>
                        
    <button class="btn btn-warning" onclick="mostrarModalEditar(<?php echo $row['id_usuario']; ?>, '<?php echo $row['nombre']; ?>', '<?php echo $row['apellido']; ?>', '<?php echo $row['correo']; ?>', '<?php echo $row['telefono']; ?>')">Editar</button>
                </td>
    <!-- Modal para editar usuario -->
<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Editar Usuario</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Formulario dentro del modal -->
                <form id="form-usuario-editar" action="admin.php" method="POST">
                    <input type="hidden" name="id_usuario" id="id_usuario"> <!-- Para enviar el ID del usuario -->
                    <div class="form-group">
                        <input type="text" class="form-control" name="nombre" id="nombre" placeholder="Nombre del usuario" required>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="apellido" id="apellido" placeholder="Apellido del usuario" required>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" name="correo" id="correo" placeholder="Correo electrónico" required>
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" name="telefono" id="telefono" placeholder="Teléfono del usuario" required>
                    </div>
                    <button type="submit" name="editar_usuario" class="btn btn-primary">Guardar Cambios</button>
                </form>
            
            </div>
        </div>
    </div>
</div>

</td>

                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </section>

    <!-- Gestiones de Reservas y Pedidos -->
    <section>
        <h2>Gestión de Reservas y Pedidos</h2>
        <h3>Reservas Activas</h3>
<div id="reservas-activas">
    <table class="table">
        <thead>
            <tr>
                <th>Nombre Usuario</th>
                <th>Nombre del Libro</th>
                <th>Estado</th>
                <th>Fecha Pedido</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result_reservas->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['nombre_usuario']; ?></td>
                    <td><?php echo $row['nombre_libro']; ?></td>
                    <td><?php echo $row['estado_libro']; ?></td> <!-- Muestra el nombre del estado -->
                    <td><?php echo $row['fecha_pedido']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

    </section>

    <section>

<h1>Gestion de Notificaciones</h1>
<<h2>Send a Notification</h2>
<form action="admin.php" method="post">
    <label for="user_id">User ID:</label>
    <input type="number" id="user_id" name="user_id" required>
    
    <label for="notification_name">Nombre de la Notificación:</label>
    <select id="notification_name" name="notification_name" required>
        <option value="">Seleccione una notificación</option>
        <?php
        // Consultar las notificaciones predefinidas
        $sql_notificaciones = "SELECT id_notificacion, nombre FROM NOTIFICACIONES_PREDEFINIDAS";
        $result_notificaciones = $connection->query($sql_notificaciones);
        
        if ($result_notificaciones->num_rows > 0) {
            while($row = $result_notificaciones->fetch_assoc()) {
                echo '<option value="' . $row['id_notificacion'] . '">' . $row['nombre'] . '</option>';
            }
        } else {
            echo '<option value="">No hay notificaciones disponibles</option>';
        }
        ?>
    </select>
    
    <button type="submit" name="send_notification">Enviar Notificación</button>
</form>


<h2>Notificaciones Enviadas</h2>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Nombre de la Notificación</th>
            <th>Mensaje</th>
            <th>Estado</th>
            <th>Fecha de Envío</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Consulta para obtener las notificaciones enviadas
        $sql_notificaciones_enviadas = "
            SELECT 
                n.id_notificacion, 
                n.nombre AS nombre_notificacion, 
                n.mensaje, 
                n.id_estado, 
                n.fecha_envio, 
                u.nombre AS nombre_usuario, 
                u.apellido 
            FROM 
                NOTIFICACIONES n 
            JOIN 
                USUARIO u ON n.id_usuario = u.id_usuario 
            ORDER BY n.fecha_envio DESC
        ";

        $result_notificaciones_enviadas = $connection->query($sql_notificaciones_enviadas);

        if ($result_notificaciones_enviadas->num_rows > 0) {
            while ($row = $result_notificaciones_enviadas->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id_notificacion'] . "</td>";
                echo "<td>" . $row['nombre_usuario'] . " " . $row['apellido'] . "</td>";
                echo "<td>" . $row['nombre_notificacion'] . "</td>";
                echo "<td>" . $row['mensaje'] . "</td>";
                echo "<td>" . ($row['id_estado'] == 1 ? 'Enviado' : 'No Enviado') . "</td>";
                echo "<td>" . $row['fecha_envio'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No hay notificaciones enviadas.</td></tr>";
        }
        ?>
    </tbody>
</table>

</section>
    <section>
    <h2>Gestión de Multas</h2>
    <form action="admin.php" method="POST">
        <label for="id_usuario">Usuario:</label>
        <select name="id_usuario" required>
            <?php
            $usuarios = $connection->query("SELECT id_usuario, nombre, apellido FROM USUARIO WHERE id_estado = 1");
            while ($usuario = $usuarios->fetch_assoc()) {
                echo "<option value='{$usuario['id_usuario']}'>{$usuario['nombre']} {$usuario['apellido']}</option>";
            }
            ?>
        </select>
        <input type="text" name="descripcion" placeholder="Descripción de la multa" required>
        <input type="number" name="precio_multa" placeholder="Precio de la multa" required>
        <button type="submit" name="agregar_multa" class="btn btn-primary">Agregar Multa</button>
    </form>
</section>

    </section>

<script>
    function mostrarOpciones(id) {
        var opciones = document.getElementById('opciones-' + id);
        if (opciones.style.display === 'none') {
            opciones.style.display = 'block';
        } else {
            opciones.style.display = 'none';
        }
    }
</script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</body>
</html>

<script>
                function mostrarModalEditar(id, nombre, apellido, correo, telefono) {
    
    document.getElementById('id_usuario').value = id;
    document.getElementById('nombre').value = nombre;
    document.getElementById('apellido').value = apellido;
    document.getElementById('correo').value = correo;
    document.getElementById('telefono').value = telefono;
 
    $('#editUserModal').modal('show');
}
</script>

<script>
    function mostrarModalEditarLibro(id, nombre, autor, stock) {
        document.getElementById('id_libro_editar').value = id;
        document.getElementById('nombre_editar').value = nombre;
        document.getElementById('autor_editar').value = autor;
        document.getElementById('stock_editar').value = stock;

        // Mostrar el modal
        $('#editBookModal').modal('show');
    }
</script>

<?php
// Cerrar la conexión
$connection->close();
?>
