<?php
session_start(); // Iniciar sesión

// Verificar si el usuario está autenticado
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Conexión a la base de datos
require 'db_connection.php';

$libros = [];

try {
    // Consultar todos los libros en la base de datos
    $queryLibros = "SELECT id_libro, nombre FROM libro";
    $stmtLibros = $conn->prepare($queryLibros);
    $stmtLibros->execute();
    $libros = $stmtLibros->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error = "Error al cargar los libros: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devolver Libro</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" crossorigin="anonymous">
    <style>
      <?php include 'styles.css' ?>
    </style>
</head>

<body>  
<div class="header">
        <div class="mr-3">
            <img class="logo" src="./img/Library Logo.png" height="100">
        </div>
        <div class="navbar d-flex justify-content-between w-100">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
                </li>
                <li class="nav-item"> 
                    <a class="nav-link" style="color:#2e4045"href="services.php">Servicios</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
                </li>
            </ul>
        </div>
    </div>

  <div class="modulo-devolucion">
        <h1>Devolución de Libros</h1>

        <!-- Mostrar mensajes de éxito o error -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success"><?= htmlspecialchars($_GET['success']) ?></div>
        <?php elseif (isset($_GET['error'])): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Mostrar lista de libros -->
        <?php if (empty($libros)): ?>
            <p>No hay libros disponibles en la base de datos.</p>
        <?php else: ?>
            <form action="devolucion.php" method="POST">
                <label for="libro_id">Selecciona el libro a devolver:</label>
                <select id="libro_id" name="libro_id" required>
                    <option value="" disabled selected>Selecciona un libro</option>
                    <?php foreach ($libros as $libro): ?>
                        <option value="<?= $libro['id_libro'] ?>">
                            <?= htmlspecialchars($libro['nombre']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary">Devolver</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
