<?php
class BookController {
    private $bookModel;

    public function __construct($model) {
        $this->bookModel = $model;
    }

    // Obtener todos los libros
    public function showBooks() {
        return $this->bookModel->getAllBooks();
    }

    // Añadir un libro
    public function addBook($titulo, $autor, $genero, $anio) {
        if (empty($titulo) || empty($autor) || empty($genero) || empty($anio)) {
            return "Todos los campos son obligatorios.";
        }
        return $this->bookModel->addBook($titulo, $autor, $genero, $anio);
    }

    // Editar un libro
    public function editBook($id, $titulo, $autor, $genero, $anio) {
        return $this->bookModel->updateBook($id, $titulo, $autor, $genero, $anio);
    }

    // Eliminar un libro
    public function deleteBook($id) {
        return $this->bookModel->deleteBook($id);
    }

    // Verificar roles de usuario
    public function verificarRol($usuario, $rolesPermitidos) {
        return in_array($usuario['rol'], $rolesPermitidos);
    }
}
?>
