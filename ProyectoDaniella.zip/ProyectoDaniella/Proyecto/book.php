<?php
class Book
{
    private $db;

    public function __construct($database)
    {
        $this->db = $database;
    }

    // Obtener todos los libros
    public function getAllBooks()
    {
        $query = $this->db->prepare("SELECT * FROM libro");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    // Añadir un libro
    public function addBook($titulo, $autor, $genero, $anio)
    {
        $query = $this->db->prepare("INSERT INTO libros (titulo, autor, genero, anio) VALUES (?, ?, ?, ?)");
        return $query->execute([$titulo, $autor, $genero, $anio]);
    }

    // Editar un libro
    public function updateBook($id, $titulo, $autor, $genero, $anio)
    {
        $query = $this->db->prepare("UPDATE libros SET titulo = ?, autor = ?, genero = ?, anio = ? WHERE id = ?");
        return $query->execute([$titulo, $autor, $genero, $anio, $id]);
    }

    // Eliminar un libro
    public function deleteBook($id)
    {
        $query = $this->db->prepare("DELETE FROM libros WHERE id = ?");
        return $query->execute([$id]);
    }
}
?>