<?php
session_start(); // Iniciar sesión

// Verificar si el usuario está autenticado
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Conexión a la base de datos
require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $libro_id = (int)$_POST['libro_id']; // Recibir el ID del libro seleccionado

    try {
        $conn->beginTransaction();

        // Verificar que el libro existe y tiene un pedido pendiente
        $queryPedido = "SELECT p.id_pedido 
                        FROM pedido p
                        WHERE p.id_libro = :libro_id AND p.id_estado = 2"; // 2: Estado pendiente
        $stmtPedido = $conn->prepare($queryPedido);
        $stmtPedido->execute(['libro_id' => $libro_id]);
        $pedido = $stmtPedido->fetch(PDO::FETCH_ASSOC);

        if (!$pedido) {
            throw new Exception("No hay pedidos pendientes para este libro.");
        }

        $pedido_id = $pedido['id_pedido'];

        // Registrar la devolución
        $queryDevolucion = "INSERT INTO devolucion (id_pedido, id_estado, fecha_caducidad)
                            VALUES (:pedido_id, 3, NOW())"; // 3: Estado devuelto
        $stmtDevolucion = $conn->prepare($queryDevolucion);
        $stmtDevolucion->execute(['pedido_id' => $pedido_id]);

        // Actualizar stock del libro
        $queryStock = "UPDATE libro SET stock = stock + 1 WHERE id_libro = :libro_id";
        $stmtStock = $conn->prepare($queryStock);
        $stmtStock->execute(['libro_id' => $libro_id]);

        // Cambiar estado del pedido
        $queryEstadoPedido = "UPDATE pedido SET id_estado = 3 WHERE id_pedido = :pedido_id";
        $stmtEstadoPedido = $conn->prepare($queryEstadoPedido);
        $stmtEstadoPedido->execute(['pedido_id' => $pedido_id]);

        $conn->commit();
        header("Location: return.php?success=Libro devuelto exitosamente.");
        exit;
    } catch (Exception $e) {
        $conn->rollBack();
        header("Location: return.php?error=" . urlencode($e->getMessage()));
        exit;
    }
} else {
    header("Location: return.php");
    exit;
}
