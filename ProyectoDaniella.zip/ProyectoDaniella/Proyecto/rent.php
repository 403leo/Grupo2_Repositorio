<?php
session_start(); // Se inicia sesión

// Se verifica si el usuario está logueado
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php"); // Redirigir al login si no está logueado
    exit;
}

// Conexión a la base de datos
require 'db_connection.php';

// Recuperar libros disponibles con stock > 0
$query = "SELECT id_libro, nombre, stock FROM libro WHERE stock > 0 AND id_estado = 1";
$result = $conn->query($query);

$libros = [];
if ($result && $result->rowCount() > 0) {
    $libros = $result->fetchAll(PDO::FETCH_ASSOC);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Préstamo de Libros</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    
<?php if (isset($_GET['message'])): ?>
    <div class="alert alert-success">
        <?php echo htmlspecialchars($_GET['message']); ?>
    </div>
<?php endif; ?>

<?php if (isset($_GET['error'])): ?>
    <div class="alert alert-danger">
        <?php echo htmlspecialchars($_GET['error']); ?>
    </div>
<?php endif; ?>

<div class="header">
        <div class="mr-3">
            <img class="logo" src="./img/Library Logo.png" height="100">
        </div>
        <div class="navbar d-flex justify-content-between w-100">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link active" style="color:#2e4045" aria-current="page" href="home.php">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color:#2e4045" href="register.php">Perfil</a>
                </li>
                <li class="nav-item"> 
                    <a class="nav-link" style="color:#2e4045"href="services.php">Servicios</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" style="color:#2e4045" href="books.php">Libros</a>
                </li>
            </ul>
        </div>
    </div>

    <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['user_name']); ?>. Reserva un libro</h1>
    <ul>
        <?php foreach ($libros as $libro): ?>
            <li>
                <?php echo htmlspecialchars($libro['nombre']) . " - Stock: " . htmlspecialchars($libro['stock']); ?>
                <a href="prestamo.php?id_libro=<?php echo $libro['id_libro']; ?>">Reservar</a>
            </li>
        <?php endforeach; ?>
    </ul>
<a href="services.php" class="btn btn-secondary mt-3">Volver al inicio</a>

    <div class="footer">
        <h3>Copyright 2024. </h3>
        <p class="time"><?php echo "Fecha: " . date('d-m-Y H:i:s'); ?></p>
    </div>

</body>
</html>
